#ifndef __VALIDATE_H__
#define __VALIDATE_H__

void printFAT();

#endif
